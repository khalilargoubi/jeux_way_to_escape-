# TheRoom-Waytoescape
this project is a 3d game created with "Unreal engine" and c++. • Escape room is considered to be a serious game since it tests the player's intelligence and reasoning. In addition, it requires reflection, a background full of cleverness and in the real world team spirit. • The concept is simple: it is A game in which participants are confined to a room or chamber (like a prison cell) given a certain amount of time to find a way to escape (like by discovering hidden clues and solving a series of riddles or puzzles)
# what are we doing ?? 
we are computer engineers at the national school of computer science(ENSI) Tunisia
# Project Structure 
I have moved all the original BASIC source code into the folder source
Each project has subfolders corresponding to the languages we’d like to see the games ported to. This is based on :

1.c++

2.c#
# Project description
The game start with a video that describe the idea of ​​the game, then a simple interface in which the player is invited to start playing or change some settings or quit the game. After pressing the start button, he enters a room where he must read two letters to understand how he is progressing and he collects 4 tools to progress towards a quiz. This quiz contains general culture questions as soon as you finish it it gives you a score and then advances you to a second room. This room also contains tools to collect and after collecting all the necessary tools, you advance to a quiz which contains computer problems and coding. Not to mention, that the player has 3 min to complete each level where he will fail
# Have fun !
Thank you for taking part in this project 
